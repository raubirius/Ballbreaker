
public interface KolíznaAkcia
{
	void vykonaj();
}
